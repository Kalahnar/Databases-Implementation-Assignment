/**
 * Represents a Lot with a name, location, capacity, and floors.
 * @author mmuppa
 *
 */
public class Lot {
	//lotName - string, location - string, capacity - int, floors int, primary key lotname
	private String lotName;
	private String lotLocation;
	private int lotCapacity;
	private int lotFloors;


	public Lot(String lotName, String lotLocation, int lotCapacity, int lotFloors) {
		setLotName(lotName);
		setLocation(lotLocation);
		setCapacity(lotCapacity);
		setFloors(lotFloors);
	}
	
//	
	/**
	 * Returns the title of the movie.
	 * @return movie title
	 */
	public String getLotName()
	{
		return lotName;
	}
	
	/**
	 * Modifies the title of the movie.
	 * @param title
	 * @throws IllegalArgumentException if title is null or empty.
	 */
	public void setLotName(String lotName)
	{
		if (lotName == null || lotName.length() == 0 )
			throw new IllegalArgumentException("Please supply a valid parking lot name.");
		this.lotName = lotName;
	}
	
	public String getLocation()
	{
		return lotLocation;
	}
	
	/**
	 * Modifies the title of the movie.
	 * @param title
	 * @throws IllegalArgumentException if title is null or empty.
	 */
	public void setLocation(String lotLocation)
	{
		if (lotLocation == null || lotLocation.length() == 0 )
			throw new IllegalArgumentException("Please supply a valid parking lot name.");
		this.lotLocation = lotLocation;
	}
	
	public int getCapacity()
	{
		return lotCapacity;
	}
	
	/**
	 * Modifies the length of the movie.
	 * @param length
	 * @throws IllegalArgumentException if length is negative or 0.
	 */
	public void setCapacity(int lotCapcity)
	{
		if (lotCapcity <= 0)
			throw new IllegalArgumentException("No parking lot has less than 10 spaces");
		
		this.lotCapacity = lotCapcity;
	}
	
	public int getFloors()
	{
		return lotFloors;
	}
	
	/**
	 * Sets the movie year.
	 * @param year
	*/
	public void setFloors(int lotFloors)
	{
		if (lotFloors < 0)
			throw new IllegalArgumentException("There cant be negative number of floors");
		
		this.lotFloors = lotFloors;
	}
	
}