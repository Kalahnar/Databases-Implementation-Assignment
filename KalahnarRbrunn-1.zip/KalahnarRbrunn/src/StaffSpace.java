public class StaffSpace {
	private int staffSpaceStaffNumber;
	private int staffSpaceSpaceNumber;
	
	
	/**
	 * Initialize the staff space parameters.
	 * @param staffSpaceStaffNumber
	 * @param staffSpaceSpaceNumber
	 * SpaceNo, StaffNo < 1.
	 */
	public StaffSpace(int staffSpaceStaffNumber, int staffSpaceSpaceNumber) {
		setStaffNo(staffSpaceStaffNumber);
		setSpaceNo(staffSpaceSpaceNumber);
	}
	
	/**
	 * Returns the StaffNo.
	 * @return StaffNo
	 */
	public int getStaffNo()
	{
		return staffSpaceStaffNumber;
	}

	/**
	 * Sets the StaffNo.
	 * @param StaffNo
	 * @throws IllegalArgumentException if StaffNo is  < 1. 
	 */
	private void setStaffNo(int StaffNo)
	{

		if (StaffNo < 1)
			throw new IllegalArgumentException("StaffNo Can't be < 1");
		this.staffSpaceStaffNumber = StaffNo;
	}
	
	/**
	 * Returns the SpaceNo.
	 * @return SpaceNo
	 */
	public int getSpaceNo()
	{
		return staffSpaceSpaceNumber;
	}

	/**
	 * Sets the SpaceNo.
	 * @param SpaceNo
	 * @throws IllegalArgumentException if SpaceNo is  < 1. 
	 */
	private void setSpaceNo(int SpaceNo){

		if (SpaceNo < 1)
			throw new IllegalArgumentException("SpaceNo Can't be < 1");
		this.staffSpaceSpaceNumber = SpaceNo;
	}
}

