
public class Space {
	//lotName - string, location - string, capacity - int, floors int, primary key lotname
	private int spaceNumber;
	private String spaceType;
	private String spaceLotName;

	public Space(int spaceNumber, String spaceType, String spaceLotName) {
		setSpaceNumber(spaceNumber);
		setSpaceType(spaceType);
		setSpaceLotName(spaceLotName);
	}
	
	
	/**
	 * Returns the SpaceType.
	 * @return SpaceType
	 */
	public String getSpaceType()
	{
		return spaceType;
	}
	
	/**
	 * Modifies the SpaceType of the space.
	 * @param SpaceType
	 * @throws IllegalArgumentException if SpaceType is null or empty.
	 */
	private void setSpaceType(String spaceType)
	{
		if (spaceType == null || spaceType.length() == 0 )
			throw new IllegalArgumentException("Please mark space type as Covered or Uncovered.");
		this.spaceType = spaceType;
	}
	
	/**
	 * Returns the SpaceType.
	 * @return SpaceType
	 */
	public String getSpaceLotName()
	{
		return spaceLotName;
	}
	
	/**
	 * Modifies the SpaceType of the space.
	 * @param SpaceType
	 * @throws IllegalArgumentException if SpaceType is null or empty.
	 */
	private void setSpaceLotName(String spaceLotName)
	{
		if (spaceLotName == null || spaceLotName.length() == 0 )
			throw new IllegalArgumentException("Please mark space type as Available or Unavailable.");
		this.spaceLotName = spaceLotName;
	}
	
	/**
	 * Returns the SpaceNo.
	 * @return SpaceNo
	 */
	public int getSpaceNumber()
	{
		return spaceNumber;
	}

	/**
	 * Sets the SpaceNo.
	 * @param SpaceNo
	 * @throws IllegalArgumentException if SpaceNo is less than 1. 
	 */
	private void setSpaceNumber(int spaceNumber)
	{
		if(spaceNumber < 1){
			throw new IllegalArgumentException("Provide a valid number");
		}
		this.spaceNumber = spaceNumber;
	}
	
}