public class UncoveredSpace {
	private int spaceNumber;
	
	
	/**
	 * Initialize the SpaceNo parameters.
	 * @param SpaceNo
	 * @throws IllegalArgumentException if spaceNo < 1
	 */
	public UncoveredSpace(int SpaceNo) {
		setSpaceNo(SpaceNo);
	}
	
	/**
	 * Returns the genre of the movie.
	 * @return genre
	 */
	public int getSpaceNo()
	{
		return spaceNumber;
	}
	
	/**
	 * Modifies the SpaceNo
	 * @param SpaceNo
	 * @throws IllegalArgumentException if SpaceNo < 1.
	 */
	private void setSpaceNo(int SpaceNo)
	{
		if(SpaceNo < 1){
			throw new IllegalArgumentException("SpaceNo can't be less than 1");
		}
		this.spaceNumber = SpaceNo;		
	}
}

