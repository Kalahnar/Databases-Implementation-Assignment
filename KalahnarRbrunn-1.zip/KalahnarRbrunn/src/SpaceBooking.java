import java.sql.Date;

public class SpaceBooking {
	private String spaceBookingVisitorLicense;
	private int spaceBookingId;
	private int spaceBookingSpaceNumber;
	private int spaceBookingStaffNumber;
	private Date spaceBookingDateOfVisit;
	
	
	/**
	 * Initialize the space booking parameters.
	 * @param VisitorLicense
	 * @param BookingId
	 * @param SpaceNumber
	 * @param StaffNumber
	 * @param DateofVisit
	 * @throws IllegalArgumentException if VisitorLic or DateOfVisi are null or empty,
	 * SpaceNo, staffNo, bookingId < 1.
	 */
	public SpaceBooking(int BookingId, int SpaceNumber, int StaffNumber, String VisitorLicense, Date DateOfVisit) {
		setVisitorLic(VisitorLicense);
		setBookingId(BookingId);
		setSpaceNo(SpaceNumber);
		setStaffNo(StaffNumber);
		setDateOfVisit(DateOfVisit);
	}

	/**
	 * Returns the VisitorLic.
	 * @return movie VisitorLic
	 */
	public String getVisitorLic()
	{
		return spaceBookingVisitorLicense;
	}
	
	/**
	 * Modifies the VisitorLic.
	 * @param VisitorLic
	 * @throws IllegalArgumentException if VisitorLic is null or empty.
	 */
	private void setVisitorLic(String VisitorLic)
	{
		if (VisitorLic == null || VisitorLic.length() == 0 )
			throw new IllegalArgumentException("Please supply a valid VisitorLic.");
		this.spaceBookingVisitorLicense = VisitorLic;
	}
	
	/**
	 * Returns the BookingId.
	 * @return BookingId
	 */
	public int getBookingId()
	{
		return spaceBookingId;
	}
	
	/**
	 * Sets the movie BookingId.
	 * @param BookingId
	 * @throws IllegalArgumentException if BookingId < 1. 
	 */
	private void setBookingId(int BookingId)
	{
		if (BookingId < 1)
			throw new IllegalArgumentException("Booking id cannot be less than 1");
		this.spaceBookingId = BookingId;
	}
	
	/**
	 * Returns the SpaceNo of the movie.
	 * @return SpaceNo
	 */
	public int getSpaceNo()
	{
		return spaceBookingSpaceNumber;
	}
	
	/**
	 * Modifies the SpaceNo
	 * @param SpaceNo
	 * @throws IllegalArgumentException if SpaceNo is negative or 0.
	 */
	private void setSpaceNo(int SpaceNo)
	{
		if (SpaceNo <= 0){
			throw new IllegalArgumentException("SpaceNo cannot be negative or 0.");
		}
		this.spaceBookingSpaceNumber = SpaceNo;
	}
	
	/**
	 * Returns the staff number.
	 * @return staff number
	 */
	public int getStaffNo()
	{
		return spaceBookingStaffNumber;
	}
	
	/**
	 * Sets the genre of the movie.
	 * @param staffNo
	 * @throws IllegalArgumentException if StaffNo < 1.
	 */
	private void setStaffNo(int StaffNo)
	{
		if (StaffNo < 1){
			throw new IllegalArgumentException("StaffNo cannot be negative or 0.");
		}
		this.spaceBookingStaffNumber = StaffNo;
	}
	
	/**
	 * Returns the name of the studio.
	 * @return studioName
	 */
	public Date getDateOfVisit()
	{
		return spaceBookingDateOfVisit;
	}
	
	/**
	 * Sets the name of the studio. 
	 * @param DateOfVisit
	 * @throws IllegalArgumentException if date of visit is null.
	 */
	private void setDateOfVisit(Date DateOfVisit)
	{
		if (DateOfVisit == null){
			throw new IllegalArgumentException("Please supply a valid date.");
		}
		this.spaceBookingDateOfVisit = DateOfVisit;
	}
}
