import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;

/**
 * A class that consists of the database operations to insert and update the Movie information.
 * @author  mmuppa
 *
 */

public class ParkingDB {
	private static String userName = "kalahnar";
	private static String password = "trecmyd";
	private static String serverName = "cssgate.insttech.washington.edu"; 
	private static Connection sConnection;
	
	private List<Lot> myLotList;
	private List<Staff> myStaffList;
	private List<Space> mySpaceList;
	private List<CoveredSpace> myCoveredSpaceList;
	private List<UncoveredSpace> myUncoveredSpaceList;
	private List<StaffSpace> myStaffSpaceList;
	private List<SpaceBooking> mySpaceBookingList;
	

	/**
	 * Creates a sql connection to MySQL using the properties for
	 * userid, password and server information.
	 * @throws SQLException
	 */
	public static void createConnection() throws SQLException {
		sConnection =  DriverManager
				.getConnection("jdbc:mysql://" + serverName + "/" + userName + "?user=" + userName + "&password=" + password);
		//Uncomment For Debugging - System.out.println("Connected to database");
	}

	/**
	 * Returns a list of lot objects from the database.
	 * @return list of lots
	 * @throws Exception 
	 */
	public List<Lot> getLots() throws Exception {
		if (sConnection == null) {
			createConnection();
		}
		Statement stmt = null;
		String query = "select lotName, lotLocation, lotCapacity, lotFloors "
				+ "from Lot ";

		myLotList = new ArrayList<Lot>();
		try {
			stmt = sConnection.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				String lotName = rs.getString("lotName");
				String lotLocation = rs.getString("lotLocation");
				int lotCapacity = rs.getInt("lotCapacity");
				int lotFloors = rs.getInt("lotFloors");
				Lot lot = new Lot(lotName, lotLocation, lotCapacity, lotFloors);
				myLotList.add(lot);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception("Unable to retrieve list of lots: " + e.getMessage());
		} finally {
			if (stmt != null) {
				stmt.close();
			}
		}
		return myLotList;
	}

	/**
	 * Filters the movie list to find the given title. Returns a list with the
	 * movie objects that match the title provided.
	 * @param title
	 * @return list of movies that contain the title.
	 */
	public List<Lot> getLots(String lotName) throws Exception {
		List<Lot> filterList = new ArrayList<Lot>();
		try {
			myLotList = getLots();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception("Unable to retrieve lots: " + e.getMessage());
		}
		for (Lot lot : myLotList) {
			if (lot.getLotName().toLowerCase().contains(lotName.toLowerCase())) {
				filterList.add(lot);
			}
		}
		return filterList;
	}

	/**
	 * Adds a new lot to the table.
	 * @param lot 
	 * @throws Exception 
	 */
	public void addLot(Lot lot) throws Exception {
		String sql = "insert into Lot values " + "(?, ?, ?, ?); ";

		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = sConnection.prepareStatement(sql);
			preparedStatement.setString(1, lot.getLotName());
			preparedStatement.setString(2, lot.getLocation());
			preparedStatement.setInt(3, lot.getCapacity());
			preparedStatement.setInt(4, lot.getFloors());
			preparedStatement.executeUpdate();
			System.out.println("Added");
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception("Unable to add Lot: " + e.getMessage());
		} 
	}

	/**
	 * Modifies the movie information corresponding to the index in the list.
	 * @param row index of the element in the list
	 * @param columnName attribute to modify
	 * @param data value to supply
	 * @throws Exception 
	 */
	public void updateLot(int row, String columnName, Object data) throws Exception {
		
		Lot lot = myLotList.get(row);
		String lotName = lot.getLotName();
		
		String sql = "update Lot set " + columnName + " = ?  where lotName = ? ";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = sConnection.prepareStatement(sql);
			if (data instanceof String) {
				preparedStatement.setString(1, (String) data);
			} else if (data instanceof Integer) {
				preparedStatement.setInt(1, (Integer) data);
			}
			preparedStatement.setString(2, lotName);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception("Unable to add Lot: " + e.getMessage());
		} 
		
	}
	public List<Staff> getStaff() throws Exception {
		if (sConnection == null) {
			createConnection();
		}
		Statement stmt = null;
		String query = "select staffNumber, staffTelephoneExt, staffVehicleLicenseNumber "
				+ "from Staff ";

		myStaffList = new ArrayList<Staff>();
		try {
			stmt = sConnection.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				String staffVehicleLicenseNumber = rs.getString("staffVehicleLicenseNumber");
				int staffNumber = rs.getInt("staffNumber");
				int staffTelephoneExt = rs.getInt("staffTelephoneExt");
				Staff staff = new Staff(staffNumber, staffTelephoneExt, staffVehicleLicenseNumber);
				myStaffList.add(staff);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("ERROR IS HERE");
			throw new Exception("Unable to retrieve list of staff: " + e.getMessage());
			
		} finally {
			if (stmt != null) {
				stmt.close();
			}
		}
		return myStaffList;
	}

	/**
	 * Filters the movie list to find the given title. Returns a list with the
	 * movie objects that match the title provided.
	 * @param title
	 * @return list of movies that contain the title.
	 */
	public List<Staff> getStaff(String staffVehicleLicenseNumber) throws Exception {
		List<Staff> filterList = new ArrayList<Staff>();
		try {
			myStaffList = getStaff();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception("Unable to retrieve staff: " + e.getMessage());
		}
		for (Staff staff : myStaffList) {
			if (staff.getLicPlateNo().toLowerCase().contains(staffVehicleLicenseNumber.toLowerCase())) {
				filterList.add(staff);
			}
		}
		return filterList;
	}

	/**
	 * Adds a new lot to the table.
	 * @param staff 
	 * @throws Exception 
	 */
	public void addStaff(Staff staff) throws Exception {
		String sql = "insert into Staff values " + "(?, ?, ?); ";

		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = sConnection.prepareStatement(sql);
			preparedStatement.setInt(1, staff.getStaffNo());
			preparedStatement.setInt(2, staff.getPhoneExt());
			preparedStatement.setString(3, staff.getLicPlateNo());
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception("Unable to add Staff: " + e.getMessage());
		} 
	}

	/**
	 * Modifies the movie information corresponding to the index in the list.
	 * @param row index of the element in the list
	 * @param columnName attribute to modify
	 * @param data value to supply
	 * @throws Exception 
	 */
	public void updateStaff(int row, String columnName, Object data) throws Exception {
		
		Staff staff = myStaffList.get(row);
		int staffNumber = staff.getStaffNo();
		
		String sql = "update Staff set " + columnName + " = ?  where staffNumber = ? ";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = sConnection.prepareStatement(sql);
			if (data instanceof String) {
				preparedStatement.setString(1, (String) data);
			} else if (data instanceof Integer) {
				preparedStatement.setInt(1, (Integer) data);
			}
			preparedStatement.setInt(2, staffNumber);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception("Unable to add Lot NEW ERROR: " + e.getMessage());
		} 
		
	}
//~~~~~~~~~~~~~~~~~~~~~~~~SPACE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	
	public List<Space> getSpace() throws Exception {
		if (sConnection == null) {
			createConnection();
		}
		Statement stmt = null;
		String query = "select spaceNumber, spaceType, spaceLotName "
				+ "from Space ";

		mySpaceList = new ArrayList<Space>();
		try {
			stmt = sConnection.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				String spaceType = rs.getString("spaceType");
				int spaceNumber = rs.getInt("spaceNumber");
				String spaceLotName = rs.getString("spaceLotName");
				Space space = new Space(spaceNumber, spaceType, spaceLotName);
				mySpaceList.add(space);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("ERROR IS HERE");
			throw new Exception("Unable to retrieve list of space: " + e.getMessage());
			
		} finally {
			if (stmt != null) {
				stmt.close();
			}
		}
		return mySpaceList;
	}

	/**
	 * Filters the movie list to find the given title. Returns a list with the
	 * movie objects that match the title provided.
	 * @param title
	 * @return list of movies that contain the title.
	 */
	public List<Space> getSpace(String spaceLotName) throws Exception {
		List<Space> filterList = new ArrayList<Space>();
		try {
			mySpaceList = getSpace();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception("Unable to retrieve space: " + e.getMessage());
		}
		for (Space space : mySpaceList) {
			if (space.getSpaceLotName().toLowerCase().contains(spaceLotName.toLowerCase())) {
				filterList.add(space);
			}
		}
		return filterList;
	}

	/**
	 * Adds a new lot to the table.
	 * @param space 
	 * @throws Exception 
	 */
	public void addSpace(Space space) throws Exception {
		String sql = "insert into Space values " + "(?, ?, ?); ";

		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = sConnection.prepareStatement(sql);
			preparedStatement.setInt(1, space.getSpaceNumber());
			preparedStatement.setString(2, space.getSpaceType());
			preparedStatement.setString(3, space.getSpaceLotName());
			preparedStatement.executeUpdate(); 
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception("Unable to add Space: " + e.getMessage());
		} 
	}
	
//~~~~~~~~~~~~~~~~~~~~ ASSIGN SPACE ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	
		public List<StaffSpace> getStaffSpace() throws Exception {
			if (sConnection == null) {
				createConnection();
			}
			Statement stmt = null;
			String query = "select staffSpaceStaffNumber, staffSpaceSpaceNumber "
					+ "from StaffSpace ";

			myStaffSpaceList = new ArrayList<StaffSpace>();
			try {
				stmt = sConnection.createStatement();
				ResultSet rs = stmt.executeQuery(query);
				while (rs.next()) {
					int staffSpaceStaffNumber = rs.getInt("staffSpaceStaffNumber");
					int staffSpaceSpaceNumber = rs.getInt("staffSpaceSpaceNumber");
					StaffSpace staffSpace = new StaffSpace(staffSpaceStaffNumber, staffSpaceSpaceNumber);
					myStaffSpaceList.add(staffSpace);
				}
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("ERROR IS HERE");
				throw new Exception("Unable to retrieve list of staffspace: " + e.getMessage());
				
			} finally {
				if (stmt != null) {
					stmt.close();
				}
			}
			return myStaffSpaceList;
		}
		
		/**
		 * Filters the movie list to find the given title. Returns a list with the
		 * movie objects that match the title provided.
		 * @param title
		 * @return list of movies that contain the title.
		 */
		public List<StaffSpace> getStaffSpace(int staffSpaceStaffNumber) throws Exception {
			List<StaffSpace> filterList = new ArrayList<StaffSpace>();
			try {
				myStaffSpaceList = getStaffSpace();
			} catch (SQLException e) {
				e.printStackTrace();
				throw new Exception("Unable to retrieve staffspace: " + e.getMessage());
			}
			for (StaffSpace staffSpace : myStaffSpaceList) {
				if (staffSpace.getStaffNo() == staffSpaceStaffNumber) {
					filterList.add(staffSpace);
				}
			}
			return filterList;
		}
		
		
		/**
		 * Adds a new lot to the table.
		 * @param staffSpace 
		 * @throws Exception 
		 */
		public void addStaffSpace(StaffSpace staffSpace) throws Exception {
			String sql = "insert into StaffSpace values " + "(?, ?); ";

			PreparedStatement preparedStatement = null;
			try {
				preparedStatement = sConnection.prepareStatement(sql);
				preparedStatement.setInt(1, staffSpace.getStaffNo());
				preparedStatement.setInt(2, staffSpace.getSpaceNo());
				preparedStatement.executeUpdate(); 
			} catch (SQLException e) {
				e.printStackTrace();
				throw new Exception("Unable to add StaffSpace: " + e.getMessage());
			} 
		}
		
		//~~~~~~~~~~~~~~~~~~~~ Space Booking ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		
			public List<SpaceBooking> getSpaceBooking() throws Exception {
				if (sConnection == null) {
					createConnection();
				}
				Statement stmt = null;
				String query = "select spaceBookingId, spaceBookingSpaceNumber, spaceBookingStaffNumber, spaceBookingVisitorLicense, spaceBookingDateOfVisit "
						+ "from SpaceBooking ";

				mySpaceBookingList = new ArrayList<SpaceBooking>();
				try {
					stmt = sConnection.createStatement();
					ResultSet rs = stmt.executeQuery(query);
					while (rs.next()) {
						int spaceBookingId = rs.getInt("spaceBookingId");
						int spaceBookingSpaceNumber = rs.getInt("spaceBookingSpaceNumber");
						int spaceBookingStaffNumber = rs.getInt("spaceBookingStaffNumber");
						String spaceBookingVisitorLicense = rs.getString("spaceBookingVisitorLicense");
						Date spaceBookingDateOfVisit = rs.getDate("spaceBookingDateOfVisit");
						
						SpaceBooking spaceBooking = new SpaceBooking(spaceBookingId, spaceBookingSpaceNumber, spaceBookingStaffNumber, spaceBookingVisitorLicense, spaceBookingDateOfVisit);
						mySpaceBookingList.add(spaceBooking);
					}
				} catch (SQLException e) {
					e.printStackTrace();
					System.out.println("ERROR IS HERE");
					throw new Exception("Unable to retrieve list of staffspace: " + e.getMessage());
					
				} finally {
					if (stmt != null) {
						stmt.close();
					}
				}
				return mySpaceBookingList;
			}
			
			/**
			 * Filters the movie list to find the given title. Returns a list with the
			 * movie objects that match the title provided.
			 * @param title
			 * @return list of movies that contain the title.
			 */
			public List<SpaceBooking> getSpaceBooking(int spaceBookingId) throws Exception {
				List<SpaceBooking> filterList = new ArrayList<SpaceBooking>();
				try {
					mySpaceBookingList = getSpaceBooking();
				} catch (SQLException e) {
					e.printStackTrace();
					throw new Exception("Unable to retrieve space Booking: " + e.getMessage());
				}
				for (SpaceBooking spaceBooking : mySpaceBookingList) {
					if (spaceBooking.getBookingId() == spaceBookingId) {
						filterList.add(spaceBooking);
					}
				}
				return filterList;
			}
			
			
			/**
			 * Adds a new lot to the table.
			 * @param spaceBooking 
			 * @throws Exception 
			 */
			public void addSpaceBooking(SpaceBooking spaceBooking) throws Exception {
				String sql = "insert into SpaceBooking values " + "(?, ?, ?, ?, ?); ";

				PreparedStatement preparedStatement = null;
				try {
					preparedStatement = sConnection.prepareStatement(sql);
					preparedStatement.setInt(1, spaceBooking.getBookingId());
					preparedStatement.setInt(2, spaceBooking.getSpaceNo());
					preparedStatement.setInt(3, spaceBooking.getStaffNo());
					preparedStatement.setString(4, spaceBooking.getVisitorLic());
					preparedStatement.setDate(5, spaceBooking.getDateOfVisit());
					preparedStatement.executeUpdate(); 
				} catch (SQLException e) {
					e.printStackTrace();
					throw new Exception("Unable to add SpaceBooking: " + e.getMessage());
				} 
			}

}
