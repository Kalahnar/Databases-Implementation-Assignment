public class Staff {
	private int staffNumber;
	private int staffTelephoneExt;
	private String staffVehicleLicenseNumber;
	
	/**
	 * Initialize the staff parameters.
	 * @param staffVehicleLicenseNumber
	 * @param staffNumber
	 * @param staffTelephoneExt
	 * @throws IllegalArgumentException if License number is null or empty,
	 * PhoneExt < 1, StaffNo < 1.
	 */
	public Staff(int staffNumber, int staffTelephoneExt, String staffVehicleLicenseNumber) {
		setStaffNo(staffNumber);
		setPhoneExt(staffTelephoneExt);
		setLicPlateNo(staffVehicleLicenseNumber);
	}

	/**
	 * Returns the LicensePlate.
	 * @return license plate
	 */
	public String getLicPlateNo()
	{
		return staffVehicleLicenseNumber;
	}
	
	/**
	 * Modifies the license plate.
	 * @param title
	 * @throws IllegalArgumentException if title is null or empty.
	 */
	public void setLicPlateNo(String staffVehicleLicenseNumber)
	{
		if (staffVehicleLicenseNumber == null || staffVehicleLicenseNumber.length() == 0 )
			throw new IllegalArgumentException("Please supply a valid license plate.");
		this.staffVehicleLicenseNumber = staffVehicleLicenseNumber;
	}
	
	/**
	 * Returns the StaffNo.
	 * @return StaffNo
	 */
	public int getStaffNo()
	{
		return staffNumber;
	}
	
	/**
	 * Sets the movie StaffNo.
	 * @param staffNumber
	 * @throws IllegalArgumentException if StaffNo < 1. 
	 */
	private void setStaffNo(int staffNumber)
	{
		if (staffNumber < 1)
			throw new IllegalArgumentException("StaffNo Can't be < 1");
		this.staffNumber = staffNumber;
	}
	
	/**
	 * Returns the PhoneExt.
	 * @return PhoneExt
	 */
	public int getPhoneExt()
	{
		return staffTelephoneExt;
	}
	
	/**
	 * Modifies the PhoneExt of the movie.
	 * @param staffTelephoneExt
	 * @throws IllegalArgumentException if PhoneExt is negative or 0.
	 */
	public void setPhoneExt(int staffTelephoneExt)
	{
		if (staffTelephoneExt < 1)
			throw new IllegalArgumentException(" PhoneExt cannot be < 1.");
		
		this.staffTelephoneExt = staffTelephoneExt;
	}
}
