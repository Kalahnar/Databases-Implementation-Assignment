import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;

/**
 * A user interface to view the movies, add a new movie and to update an existing movie.
 * The list is a table with all the movie information in it. The TableModelListener listens to
 * any changes to the cells to modify the values for reach movie.
 * @author mmuppa
 *
 */
public class ParkingGUI extends JFrame implements ActionListener, TableModelListener
{
	
	private static final long serialVersionUID = 1779520078061383929L;
	private ParkingDB db;
	private List<Lot> myLotList;
	private List<Staff> myStaffList;
	private List<Space> mySpaceList;
	private List<CoveredSpace> myCoveredSpaceList;
	private List<UncoveredSpace> myUncoveredSpaceList;
	private List<StaffSpace> myStaffSpaceList;
	private List<SpaceBooking> mySpaceBookingList;
	private String[] lotNames = {"lotName","lotLocation", "lotCapacity", "lotFloors"};
	private String[] staffNames = {"staffNumber","staffTelephoneExt","staffVehicleLicenseNumber"};
	private String[] spaceNames = {"spaceNumber", "spaceType", "spaceLotName"};
	
	private Object[][] data;
	private JPanel pnlButtons, pnlContent;//pnl buttons is the row of buttons and the pnl content is what is going ot be shown there
	
//~~~~~~~~~~~~~~~~~~~~~~~ LOT BUTTON SETUP ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	private JButton btnLotList, btnLotAdd;//buttons for lots
	private JButton btnAddLot;
	
	private JPanel  pnlAddLot;
	
	private JTable lotTable;
	private JScrollPane lotScrollPane;//in case size of gui isnt big enough to scroll through information
	
	private JTextField lotTxtFile;
	
	private JLabel[] lotTxtLabel = new JLabel[4];
	private JTextField[] lotTxtField = new JTextField[4];
//~~~~~~~~~~~~~~~~~~~~~~~ STAFF BUTTON SETUP ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	private JButton btnStaffList, btnStaffAdd;//buttons for lots
	private JButton btnAddStaff;
			
	private JPanel pnlListStaff, pnlAddStaff;
		
	private JTable staffTable;
	private JScrollPane staffScrollPane;//in case size of gui isnt big enough to scroll through information in the list panel
		
	private JLabel[] staffTxtLabel = new JLabel[3];
	private JTextField[] staffTxtField = new JTextField[3];
	//~~~~~~~~~~~~~~~~~~~~~~~ SPACE BUTTON SETUP ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	private JButton btnSpaceAdd;//buttons for lots
	private JButton btnAddSpace;
		
	private JPanel pnlAddSpace;

	private JLabel informationLabel = new JLabel();	
	private JLabel[] spaceTxtLabel = new JLabel[3];
	private JTextField[] spaceTxtField = new JTextField[3];
	//~~~~~~~~~~~~~~~~~~~ASSIGN SPOPT~~~~~~~~~~~~~~~~~~~~~~
	private JButton btnAssignSpace;
	private JButton btnAssign;
	
	private JPanel pnlAssignSpace;
	
	private JLabel[] assignTxtLabel = new JLabel[2];
	private JTextField[] assignTxtField = new JTextField[2];
	// ~~~~~~~~~~~~~~~~~~~~~~~ spaceBooking SETU ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	private JButton btnSpaceBooking;// buttons for lots
	private JButton btnBook;

	private JPanel pnlSpaceBooking;

	private JTable spaceBookingTable;

	private JLabel[] bookingTxtLabel = new JLabel[5];
	private JTextField[] bookingTxtField = new JTextField[5];
	// ~~~~~~~~~~~~~~~~~~~~~~~ STAFF BUTTON SETUP
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	
	

	/**
	 * Creates the frame and components and launches the GUI.
	 */
	public ParkingGUI() {
		super("Parking Reservation");
		
		db = new ParkingDB();
		
		try
		{
			myLotList = db.getLots();
			
			data = new Object[myLotList.size()][lotNames.length];
			for (int i=0; i<myLotList.size(); i++) {
				data[i][0] = myLotList.get(i).getLotName();
				data[i][1] = myLotList.get(i).getLocation();
				data[i][2] = myLotList.get(i).getCapacity();
				data[i][3] = myLotList.get(i).getFloors();
				
			}
			
		} catch (Exception e)
		{
			JOptionPane.showMessageDialog(this,"Error: " + e.getMessage());
			return;
		}
		createComponents();
		setVisible(true);
		setSize(700, 500);
		setResizable(false);
	}
    
	/**
	 * Creates panels for Movie list, search, add and adds the corresponding 
	 * components to each panel.
	 */
	private void createComponents()
	{
		pnlButtons = new JPanel();
		
//~~~~~~~~~~~ADDING BUTTONS FOR LOT ~~~~~~~~~~~~~~~~~~		
		btnLotList = new JButton("Lot List");
		btnLotList.addActionListener(this);
		
		btnLotAdd = new JButton("Add Lot");
		btnLotAdd.addActionListener(this);
		
		pnlButtons.add(btnLotList);
		pnlButtons.add(btnLotAdd);
		
//~~~~~~~~~~~ADDING BUTTONS FOR STAFF ~~~~~~~~~~~~~~~~~~
		btnStaffList = new JButton("Staff List");
		btnStaffList.addActionListener(this);
		
		btnStaffAdd = new JButton("Add Staff");
		btnStaffAdd.addActionListener(this);
		
		pnlButtons.add(btnStaffList);
		pnlButtons.add(btnStaffAdd);
		
// ~~~~~~~~~~~ADDING BUTTONS FOR STAFF ~~~~~~~~~~~~~~~~~~
		btnSpaceAdd = new JButton("Add Space");
		btnSpaceAdd.addActionListener(this);

		pnlButtons.add(btnSpaceAdd);
// ~~~~~~~~~~~ADDING BUTTONS FOR Assing Spot ~~~~~~~~~~~~~~~~~~
		btnAssignSpace = new JButton("Assign Space");
		btnAssignSpace.addActionListener(this);

		pnlButtons.add(btnAssignSpace);
// ~~~~~~~~~~~ADDING BUTTONS FOR Reserve Spot ~~~~~~~~~~~~~~~~~~
		btnSpaceBooking = new JButton("Book Space");
		btnSpaceBooking.addActionListener(this);

		pnlButtons.add(btnSpaceBooking);
				
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	
		
		
		add(pnlButtons, BorderLayout.NORTH);
		
		pnlContent = new JPanel();
		//Lot List Panel
		lotTable = new JTable(data, lotNames);
		lotScrollPane = new JScrollPane(lotTable);
		pnlContent.add(lotScrollPane);
		//lotTable.getModel().addTableModelListener(this);
		
		//Staff List Panel
		staffTable = new JTable(data, staffNames);
		staffScrollPane = new JScrollPane(staffTable);
		pnlContent.add(staffScrollPane);
		staffTable.getModel().addTableModelListener(this);

		
		//Lot Add Panel
		pnlAddLot = new JPanel();
		pnlAddLot.setLayout(new GridLayout(6, 0));
		String lotNames[] = {"Enter Lot Name: ", "Enter Location: ", "Enter Capacity: ", "Enter Floors: "};
		for (int i=0; i<lotNames.length; i++) {
			JPanel lotPanel = new JPanel();
			lotTxtLabel[i] = new JLabel(lotNames[i]);
			lotTxtField[i] = new JTextField(25);
			lotPanel.add(lotTxtLabel[i]);
			lotPanel.add(lotTxtField[i]);
			pnlAddLot.add(lotPanel);
		}
		JPanel lotPanel = new JPanel();
		btnAddLot = new JButton("Add");
		btnAddLot.addActionListener(this);
		lotPanel.add(btnAddLot);
		pnlAddLot.add(lotPanel);
		
		// Add Staff Panel
		pnlAddStaff = new JPanel();
		pnlAddStaff.setLayout(new GridLayout(6, 0));
		String staffNames[] = {"Enter Staff Number: ", "Enter Phone Extension: ", "Enter Vehicle License Number: "};
		for (int i=0; i<staffNames.length; i++) {
			JPanel staffPanel = new JPanel();
			staffTxtLabel[i] = new JLabel(staffNames[i]);
			staffTxtField[i] = new JTextField(25);
			staffPanel.add(staffTxtLabel[i]);
			staffPanel.add(staffTxtField[i]);
			pnlAddStaff.add(staffPanel);
		}
		JPanel staffPanel = new JPanel();
		btnAddStaff = new JButton("Add");
		btnAddStaff.addActionListener(this);
		staffPanel.add(btnAddStaff);
		pnlAddStaff.add(staffPanel);
		
		// Add Space Panel
		pnlAddSpace = new JPanel();
		pnlAddSpace.setLayout(new GridLayout(6, 0));
		String spaceNames[] = {"Enter Space Number: ", "Enter Space Type: ", "Enter Lot Name: "};
		for (int i=0; i<spaceNames.length; i++) {
			JPanel spacePanel = new JPanel();
			spaceTxtLabel[i] = new JLabel(spaceNames[i]);
			spaceTxtField[i] = new JTextField(25);
			spacePanel.add(spaceTxtLabel[i]);
			spacePanel.add(spaceTxtField[i]);
			pnlAddSpace.add(spacePanel);
		}
		JPanel spacePanel = new JPanel();
		btnAddSpace = new JButton("Add");
		btnAddSpace.addActionListener(this);
		informationLabel = new JLabel("SpaceType can only be COVERED or UNCOVERED");
		spacePanel.add(informationLabel);
		spacePanel.add(btnAddSpace);
		pnlAddSpace.add(spacePanel);
		
		// AssignSpace Panel
		pnlAssignSpace = new JPanel();
		pnlAssignSpace.setLayout(new GridLayout(6, 0));
		String assignNames[] = {"Enter Staff Number: ", "Enter Space Number: "};
		for (int i=0; i<assignNames.length; i++) {
			JPanel assignPanel = new JPanel();
			assignTxtLabel[i] = new JLabel(assignNames[i]);
			assignTxtField[i] = new JTextField(25);
			assignPanel.add(assignTxtLabel[i]);
			assignPanel.add(assignTxtField[i]);
			pnlAssignSpace.add(assignPanel);
		}
		JPanel assignPanel = new JPanel();
		btnAssign = new JButton("Assign");
		btnAssign.addActionListener(this);
		assignPanel.add(btnAssign);
		pnlAssignSpace.add(assignPanel);
		
		// SpaceBooking Panel
		pnlSpaceBooking = new JPanel();
		pnlSpaceBooking.setLayout(new GridLayout(6, 0));
		String spaceBooking[] = {"Enter Booking ID: ", "Enter Space Number: ", "Enter Staff Number: ", "Enter Visiotr License: ", "Enter Date of Visit: "};
		for (int i=0; i<spaceBooking.length; i++) {
			JPanel bookingPanel = new JPanel();
			bookingTxtLabel[i] = new JLabel(spaceBooking[i]);
			bookingTxtField[i] = new JTextField(25);
			bookingPanel.add(bookingTxtLabel[i]);
			bookingPanel.add(bookingTxtField[i]);
			pnlSpaceBooking.add(bookingPanel);
		}
		JPanel bookingPanel = new JPanel();
		btnBook = new JButton("Book");
		btnBook.addActionListener(this);
		bookingPanel.add(btnBook);
		pnlSpaceBooking.add(bookingPanel);
		
		
		
		
		add(pnlContent, BorderLayout.CENTER);
		
		
	}

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		ParkingGUI parkingGUI = new ParkingGUI();
		parkingGUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	/**
	 * Event handling to change the panels when different tabs are clicked,
	 * add and search buttons are clicked on the corresponding add and search panels.
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnLotList) {
			try {
				myLotList = db.getLots();
			} catch (Exception exception) {
				JOptionPane.showMessageDialog(this, exception.getMessage());
				return;
			}
			data = new Object[myLotList.size()][lotNames.length];
			for (int i=0; i<myLotList.size(); i++) {
				data[i][0] = myLotList.get(i).getLotName();
				data[i][1] = myLotList.get(i).getLocation();
				data[i][2] = myLotList.get(i).getCapacity();
				data[i][3] = myLotList.get(i).getFloors();
			}
			pnlContent.removeAll();//first remove everything from the panel
			lotTable = new JTable(data, lotNames);//populate the table with data
			lotTable.getModel().addTableModelListener(this);//add listener to the tabel
			lotScrollPane = new JScrollPane(lotTable);//add scrolling option to the table
			pnlContent.add(lotScrollPane);//add scrolling pane to the content panel
			pnlContent.revalidate(); //i have no fucking clue
			this.repaint(); //repaint
			
		} else if (e.getSource() == btnStaffList) {
			try {
				myStaffList = db.getStaff();
			} catch (Exception exception) {
				JOptionPane.showMessageDialog(this, exception.getMessage());
				return;
			}
			data = new Object[myStaffList.size()][staffNames.length];
			for (int i=0; i<myStaffList.size(); i++) {
				data[i][0] = myStaffList.get(i).getStaffNo();
				data[i][1] = myStaffList.get(i).getPhoneExt();
				data[i][2] = myStaffList.get(i).getLicPlateNo();
			}
			pnlContent.removeAll();//first remove everything from the panel
			staffTable = new JTable(data, staffNames);//populate the table with data
			//staffTable.getModel().addTableModelListener(this);//add listener to the tabel
			staffScrollPane = new JScrollPane(staffTable);//add scrolling option to the table
			pnlContent.add(staffScrollPane);//add scrolling pane to the content panel
			pnlContent.revalidate(); //i have no fucking clue
			this.repaint(); //repaint
			
		} else if (e.getSource() == btnLotAdd) {
			pnlContent.removeAll();
			pnlContent.add(pnlAddLot);
			pnlContent.revalidate();
			this.repaint();
			
		} else if (e.getSource() == btnStaffList) {
			pnlContent.removeAll();
			pnlContent.add(pnlListStaff);
			pnlContent.revalidate();
			this.repaint();
		} else if (e.getSource() == btnStaffAdd) {
			pnlContent.removeAll();
			pnlContent.add(pnlAddStaff);
			pnlContent.revalidate();
			this.repaint();
			
		} else if (e.getSource() == btnSpaceAdd) {
			pnlContent.removeAll();
			pnlContent.add(pnlAddSpace);
			pnlContent.revalidate();
			this.repaint();
			
		} else if (e.getSource() == btnAssignSpace) {
			pnlContent.removeAll();
			pnlContent.add(pnlAssignSpace);
			pnlContent.revalidate();
			this.repaint();
			
		} else if (e.getSource() == btnSpaceBooking) {
			pnlContent.removeAll();
			pnlContent.add(pnlSpaceBooking);
			pnlContent.revalidate();
			this.repaint();
			
		} else if (e.getSource() == btnAddLot) {
			Lot lot = new Lot(lotTxtField[0].getText(), lotTxtField[1].getText(), 
					Integer.parseInt(lotTxtField[2].getText()), Integer.parseInt(lotTxtField[3].getText()));
			try {
				db.addLot(lot);
			}
			catch(Exception exception) {
				JOptionPane.showMessageDialog(this, exception.getMessage());
				return;
			}
			JOptionPane.showMessageDialog(null, "Added Successfully!");
			for (int i=0; i<lotTxtField.length; i++) {
				lotTxtField[i].setText("");
			}
			
		} else if (e.getSource() == btnAddStaff) {
			Staff staff = new Staff(Integer.parseInt(staffTxtField[0].getText()), Integer.parseInt(staffTxtField[1].getText()), staffTxtField[2].getText());
			try {
				db.addStaff(staff);
			}
			catch(Exception exception) {
				JOptionPane.showMessageDialog(this, exception.getMessage());
				return;
			}
			JOptionPane.showMessageDialog(null, "Added Successfully!");
			for (int i=0; i<staffTxtField.length; i++) {
				staffTxtField[i].setText("");
			}
			
		} else if (e.getSource() == btnAddSpace) {//btn within add space panel taht adds
			Space space = new Space(Integer.parseInt(spaceTxtField[0].getText()), spaceTxtField[1].getText(), spaceTxtField[2].getText());
			try {
				db.addSpace(space);
				
			}
			catch(Exception exception) {
				JOptionPane.showMessageDialog(this, exception.getMessage());
				return;
			}
			for (int i=0; i<spaceTxtField.length; i++) {
				spaceTxtField[i].setText("");
			}
			
		} else if (e.getSource() == btnAssign) {//assign Staff Space
			StaffSpace staffSpace = new StaffSpace(Integer.parseInt(assignTxtField[0].getText()), Integer.parseInt(assignTxtField[1].getText()));
			try {
				db.addStaffSpace(staffSpace);
			}
			catch(Exception exception) {
				JOptionPane.showMessageDialog(this, exception.getMessage());
				return;
			}
			JOptionPane.showMessageDialog(null, "Added Successfully!");
			for (int i=0; i<assignTxtField.length; i++) {
				assignTxtField[i].setText("");
			}
			
		} else if (e.getSource() == btnBook) {//Booking Space
			
//			String bookinDate = bookingTxtField[4].toString();
//			SimpleDateFormat sdf1 = new SimpleDateFormat("MM-dd-yyyy");
//			java.util.Date date = sdf1.parse(bookinDate);
//			java.sql.Date sqlStartDate = new java.sql.Date(date.getTime());
			SpaceBooking spaceBooking = new SpaceBooking(Integer.parseInt(bookingTxtField[0].getText()), Integer.parseInt(bookingTxtField[1].getText()), 
					Integer.parseInt(bookingTxtField[2].getText()), bookingTxtField[3].getText(), Date.valueOf(bookingTxtField[4].getText()));
			try {
				db.addSpaceBooking(spaceBooking);
			}
			catch(Exception exception) {
				JOptionPane.showMessageDialog(this, exception.getMessage());
				return;
			}
			JOptionPane.showMessageDialog(null, "Added Successfully!");
			for (int i=0; i<bookingTxtField.length; i++) {
				bookingTxtField[i].setText("");
			}
			
		} 
		
	}

	/**
	 * Event handling for any cell being changed in the table.
	 */
	@Override
	public void tableChanged(TableModelEvent e) {
		int row = e.getFirstRow();
        int column = e.getColumn();
        TableModel model = (TableModel)e.getSource();
        String columnName = model.getColumnName(column);
        Object data = model.getValueAt(row, column);
        try {
//        	if(e.getSource() == lotTable) {
//        	 db.updateLot(row, columnName, data);
//        	} else {
        		if(columnName != "staffNumber") {
        			db.updateStaff(row, columnName, data);
        		} else {
        			JOptionPane.showMessageDialog(this, "Can't update staffNumber");
        		}
        		
        		
        	//}
		}
		catch(Exception exception) {
			JOptionPane.showMessageDialog(this, exception.getMessage());
			return;
		}
       
		
	}
	
	

}
