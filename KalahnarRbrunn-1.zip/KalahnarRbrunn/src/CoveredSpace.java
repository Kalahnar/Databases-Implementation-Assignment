public class CoveredSpace {
	private int coveredSpaceNumber;
	private double coveredMonthlyRate;
	
	
	/**
	 * Initialize the covered space parameters.
	 * @param monthlyRate
	 * @param SpaceNo
	 * @throws IllegalArgumentException if montlyRate < 0, spaceNo < 1.
	 */
	public CoveredSpace(int spaceNumber, double monthlyRate) {
		setSpaceNo(spaceNumber);
		setMonthlyRate(monthlyRate);
	}
	
	/**
	 * Returns the space number.
	 * @return genre
	 */
	public int getSpaceNumber()
	{
		return coveredSpaceNumber;
	}
	
	public double getMonthlyRate(){
		return this.coveredMonthlyRate;
	}
	

	/**
	 * Sets the SpaceNo.
	 * @param SpaceNo
	 * @throws IllegalArgumentException if SpaceNo is less than 1. 
	 */
	private void setSpaceNo(int spaceNumber)
	{
		if(spaceNumber < 1){
			throw new IllegalArgumentException("Provide a valid number");
		}
		this.coveredSpaceNumber = spaceNumber;
	}
	

	/**
	 * Sets the monthly rate.
	 * @param monthlyRate2
	 * @throws IllegalArgumentException if SpaceNo is less than 0. 
	 */
	private void setMonthlyRate(double monthlyRate2)
	{
		if(coveredSpaceNumber < 0){
			throw new IllegalArgumentException("Provide a valid number");
		}
		this.coveredMonthlyRate = monthlyRate2;
	}
}

