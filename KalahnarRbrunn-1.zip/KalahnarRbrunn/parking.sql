-- CREATE DATABASE ParkingDB;
-- USE ParkingDB;

DROP TABLE IF EXISTS SpaceBooking;
Drop TABLE IF EXISTS StaffSpace;
DROP TABLE IF EXISTS CoveredSpace;
DROP TABLE IF EXISTS UncoveredSpace;
DROP TABLE IF EXISTS Space;
DROP TABLE IF EXISTS Staff;
DROP TABLE IF EXISTS Lot;

CREATE TABLE Lot (
	lotName VARCHAR(30) PRIMARY KEY,
    lotLocation 	VARCHAR(30),
    lotCapacity  INT,
    lotFloors INT
    );
    
    CREATE TABLE Space (
    spaceNumber INT PRIMARY KEY,
    spaceType VARCHAR(50),
    spaceLotName VARCHAR(50),
    FOREIGN KEY (spaceLotName) REFERENCES Lot(lotName)
    );
    
    CREATE TABLE UncoveredSpace (
    uncoveredSpaceNumber INT PRIMARY KEY,
    FOREIGN KEY (uncoveredSpaceNumber) REFERENCES Space(spaceNumber)
    );
    
    CREATE TABLE CoveredSpace (
    coveredSpaceNumber INT PRIMARY KEY,
    coveredMonthlyRate INT,
    FOREIGN KEY (coveredSpaceNumber) REFERENCES Space(spaceNumber)
    );
    
    CREATE TABLE Staff (
    staffNumber INT PRIMARY KEY,
    staffTelephoneExt INT,
    staffVehicleLicenseNumber VARCHAR(50)
    );
    
	CREATE TABLE StaffSpace (
    staffSpaceStaffNumber INT,
    staffSpaceSpaceNumber INT,
    PRIMARY KEY(staffSpaceStaffNumber, staffSpaceSpaceNumber),
    FOREIGN KEY (staffSpaceStaffNumber) REFERENCES Staff(staffNumber),
    FOREIGN KEY (staffSpaceSpaceNumber) REFERENCES Space(spaceNumber)
    );
    CREATE TABLE SpaceBooking (
    spaceBookingId INT PRIMARY KEY,
    spaceBookingSpaceNumber INT,
    spaceBookingStaffNumber INT,
    spaceBookingVisitorLicense VARCHAR(20),
    spaceBookingDateOfVisit DATETIME,
    FOREIGN KEY (spaceBookingSpaceNumber) REFERENCES Space(SpaceNumber),
    FOREIGN KEY (spaceBookingStaffNumber) REFERENCES Staff(staffNumber)
    );
    

INSERT INTO Lot VALUES 
('Lot A', '123 Maple St.,Hollywood', 20, 4),
('Lot B', '456 Oak Rd., Malibu', 20, 3),
('Lot C', '789 Palm Dr., Beverly Hills', 20, 50);

DROP TABLE Staff;
INSERT INTO Staff VALUES
(001, 123456, 1111111),
(002, 654321, 2222222),
(003, 112233, 3333333);




SELECT *
FROM Lot JOIN Space ON lotName = spaceLotName
JOIN StaffSpace ON spaceNumber = staffSpaceSpaceNumber;

SELECT * 
FROM Lot, Staff, Space, StaffSpace
GROUP BY Staff.staffNumber;


